export interface Movie {
    Title: string,
    Year: number,
    imdbID: string,
    Poster: string
}
