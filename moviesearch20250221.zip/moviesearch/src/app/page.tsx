export default function Page() {
  return (
    <div>
        <h1>Moviesearch</h1>
        <p>A moviesearch app</p>
        <ul>
          <li>Item 1</li>
          <li>Item 2</li>
        </ul>
    </div>
  )
}
